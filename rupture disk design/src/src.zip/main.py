import mgui as mg

if __name__ == '__main__':
    
      
    mg.main()